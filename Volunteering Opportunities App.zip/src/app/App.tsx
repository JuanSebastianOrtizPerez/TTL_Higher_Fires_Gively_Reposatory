import { useState } from "react";
import {
  MapPin,
  Clock,
  Users,
  Mail,
  Phone,
  Globe,
  X,
  Search,
  ChevronDown,
  Plus,
  ArrowRight,
  Building2,
  Heart,
  Leaf,
  BookOpen,
  Palette,
  Stethoscope,
  Send,
  CheckCircle,
  User,
  FileText,
  Calendar,
} from "lucide-react";

type Category = "All" | "Environment" | "Education" | "Health" | "Arts" | "Community";

interface Company {
  name: string;
  logo: string;
  website: string;
  email: string;
  phone: string;
  description: string;
}

interface Opportunity {
  id: number;
  title: string;
  company: Company;
  category: Exclude<Category, "All">;
  location: string;
  commitment: string;
  spots: number;
  posted: string;
  description: string;
  skills: string[];
  image: string;
}

const OPPORTUNITIES: Opportunity[] = [
  {
    id: 1,
    title: "Urban Reforestation Crew",
    company: {
      name: "GreenCity Alliance",
      logo: "GC",
      website: "greencityalliance.org",
      email: "volunteer@greencityalliance.org",
      phone: "+1 (503) 442-7890",
      description: "A nonprofit dedicated to urban greening initiatives across the Pacific Northwest.",
    },
    category: "Environment",
    location: "Portland, OR",
    commitment: "Every Saturday, 8am–12pm",
    spots: 12,
    posted: "June 28, 2026",
    description:
      "Join our weekend crews planting native trees and shrubs across Portland neighborhoods. No experience required — we supply all tools and training. You will leave each session having planted dozens of trees that will grow for generations.",
    skills: ["Physical fitness", "Teamwork", "Outdoors"],
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "Adult Literacy Tutor",
    company: {
      name: "Open Pages Foundation",
      logo: "OP",
      website: "openpagesfoundation.org",
      email: "tutors@openpagesfoundation.org",
      phone: "+1 (206) 881-3344",
      description: "We connect adult learners with volunteer tutors to build fundamental literacy skills.",
    },
    category: "Education",
    location: "Seattle, WA (Remote OK)",
    commitment: "2 hrs/week, flexible",
    spots: 30,
    posted: "June 25, 2026",
    description:
      "Work one-on-one with adult learners aged 18–65 to develop reading and writing skills. Sessions can be held in-person at our community centers or via video call. Training and curriculum materials are provided.",
    skills: ["Communication", "Patience", "Teaching"],
    image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "Community Health Screener",
    company: {
      name: "Wellbridge Clinics",
      logo: "WB",
      website: "wellbridgeclinics.org",
      email: "outreach@wellbridgeclinics.org",
      phone: "+1 (415) 209-5570",
      description: "A network of free clinics bringing preventive healthcare to underserved communities.",
    },
    category: "Health",
    location: "San Francisco, CA",
    commitment: "One weekend/month",
    spots: 8,
    posted: "June 22, 2026",
    description:
      "Support our mobile health unit by checking in patients, recording vitals, and guiding visitors through free screening stations. Medical background preferred but not required — we train all volunteers thoroughly.",
    skills: ["Healthcare interest", "Organization", "Bilingual a plus"],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: 4,
    title: "Youth Mural Project Lead",
    company: {
      name: "Chromatic Arts Collective",
      logo: "CA",
      website: "chromaticarts.org",
      email: "hello@chromaticarts.org",
      phone: "+1 (773) 360-9982",
      description: "We use public art and creative programming to build community pride in Chicago neighborhoods.",
    },
    category: "Arts",
    location: "Chicago, IL",
    commitment: "6 weeks, Tues & Thurs evenings",
    spots: 4,
    posted: "July 1, 2026",
    description:
      "Mentor a team of 8–12 teenagers through the design and painting of a 40-foot exterior mural. You will guide the creative process, teach basic mural techniques, and help young artists bring their vision to life on a highly visible public wall.",
    skills: ["Visual art", "Youth mentorship", "Spray or brush painting"],
    image: "https://images.unsplash.com/photo-1561214115-f2f134cc4912?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: 5,
    title: "Neighborhood Food Pantry Coordinator",
    company: {
      name: "Common Table Network",
      logo: "CT",
      website: "commontablenetwork.org",
      email: "volunteers@commontablenetwork.org",
      phone: "+1 (617) 554-0021",
      description: "A Boston-based mutual aid network running eight neighborhood food pantries.",
    },
    category: "Community",
    location: "Boston, MA",
    commitment: "Wednesdays, 3–7pm",
    spots: 20,
    posted: "June 30, 2026",
    description:
      "Help sort and distribute donated food at our Jamaica Plain pantry. Volunteers assist with intake, organize shelves, and interact directly with neighbors picking up groceries. Light lifting required.",
    skills: ["Organization", "Warmth", "Light lifting"],
    image: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800&h=500&fit=crop&auto=format",
  },
  {
    id: 6,
    title: "Watershed Monitoring Volunteer",
    company: {
      name: "River Stewards Collective",
      logo: "RS",
      website: "riverstewards.org",
      email: "science@riverstewards.org",
      phone: "+1 (512) 778-4430",
      description: "Citizen science organization tracking water quality across Texas river systems.",
    },
    category: "Environment",
    location: "Austin, TX",
    commitment: "Monthly, half-day",
    spots: 15,
    posted: "June 18, 2026",
    description:
      "Collect water quality samples from assigned sites along the Colorado River watershed. Volunteers use our standardized testing kits, upload data to our dashboard, and attend a quarterly debrief with the science team.",
    skills: ["Science curiosity", "Outdoors", "Basic data entry"],
    image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&h=500&fit=crop&auto=format",
  },
];

const CATEGORY_ICONS: Record<Exclude<Category, "All">, React.ReactNode> = {
  Environment: <Leaf size={14} />,
  Education: <BookOpen size={14} />,
  Health: <Stethoscope size={14} />,
  Arts: <Palette size={14} />,
  Community: <Heart size={14} />,
};

const CATEGORY_COLORS: Record<Exclude<Category, "All">, string> = {
  Environment: "bg-emerald-100 text-emerald-800",
  Education: "bg-sky-100 text-sky-800",
  Health: "bg-rose-100 text-rose-800",
  Arts: "bg-violet-100 text-violet-800",
  Community: "bg-amber-100 text-amber-800",
};

interface PostForm {
  title: string;
  companyName: string;
  website: string;
  email: string;
  phone: string;
  category: Exclude<Category, "All">;
  location: string;
  commitment: string;
  spots: string;
  description: string;
  skills: string;
}

const EMPTY_FORM: PostForm = {
  title: "",
  companyName: "",
  website: "",
  email: "",
  phone: "",
  category: "Community",
  location: "",
  commitment: "",
  spots: "",
  description: "",
  skills: "",
};

export default function App() {
  const [view, setView] = useState<"browse" | "post">("browse");
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [contactModal, setContactModal] = useState<Opportunity | null>(null);
  const [detailModal, setDetailModal] = useState<Opportunity | null>(null);
  const [applyModal, setApplyModal] = useState<Opportunity | null>(null);
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyForm, setApplyForm] = useState({ firstName: "", lastName: "", email: "", phone: "", availability: "", experience: "", motivation: "" });
  const [postForm, setPostForm] = useState<PostForm>(EMPTY_FORM);
  const [postSuccess, setPostSuccess] = useState(false);

  const categories: Category[] = ["All", "Environment", "Education", "Health", "Arts", "Community"];

  const filtered = OPPORTUNITIES.filter((o) => {
    const matchesCategory = selectedCategory === "All" || o.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      o.title.toLowerCase().includes(q) ||
      o.company.name.toLowerCase().includes(q) ||
      o.location.toLowerCase().includes(q) ||
      o.description.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setApplySuccess(true);
    setTimeout(() => {
      setApplySuccess(false);
      setApplyModal(null);
      setApplyForm({ firstName: "", lastName: "", email: "", phone: "", availability: "", experience: "", motivation: "" });
    }, 3000);
  };

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    setPostSuccess(true);
    setPostForm(EMPTY_FORM);
    setTimeout(() => {
      setPostSuccess(false);
      setView("browse");
    }, 2800);
  };

  return (
    <div className="min-h-screen bg-background font-[DM_Sans,sans-serif]">
      {/* Nav */}
      <nav className="sticky top-0 z-40 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <Heart size={14} className="text-primary-foreground" fill="currentColor" />
            </div>
            <span
              className="text-lg font-[Playfair_Display,serif] font-semibold text-foreground tracking-tight"
            >
              Volunect
            </span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setView("browse")}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                view === "browse"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              Browse
            </button>
            <button
              onClick={() => { setView("post"); setPostSuccess(false); }}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-1.5 ${
                view === "post"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Plus size={14} />
              Post Opportunity
            </button>
          </div>
        </div>
      </nav>

      {/* Browse View */}
      {view === "browse" && (
        <div>
          {/* Hero */}
          <div className="max-w-6xl mx-auto px-6 pt-16 pb-12">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-end">
              <div className="lg:col-span-3">
                <p className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-accent mb-4">
                  Community volunteering platform
                </p>
                <h1
                  className="font-[Playfair_Display,serif] text-5xl lg:text-6xl font-bold text-foreground leading-[1.1] mb-6"
                >
                  Give your time<br />
                  <span className="italic text-primary">where it matters.</span>
                </h1>
                <p className="text-muted-foreground text-lg leading-relaxed max-w-lg">
                  Discover meaningful volunteer opportunities from organizations doing real work in your community — and get in touch directly.
                </p>
              </div>
              <div className="lg:col-span-2 flex gap-4 justify-end">
                <div className="text-right">
                  <p className="font-[Playfair_Display,serif] text-4xl font-bold text-foreground">{OPPORTUNITIES.length}</p>
                  <p className="text-sm text-muted-foreground mt-1">Open listings</p>
                </div>
                <div className="w-px bg-border self-stretch" />
                <div className="text-right">
                  <p className="font-[Playfair_Display,serif] text-4xl font-bold text-foreground">
                    {OPPORTUNITIES.reduce((s, o) => s + o.spots, 0)}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Spots available</p>
                </div>
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="max-w-6xl mx-auto px-6 mb-10">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
              {/* Search */}
              <div className="relative flex-1 max-w-sm">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search opportunities…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-card border border-border rounded-full text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                />
              </div>
              {/* Categories */}
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all border ${
                      selectedCategory === cat
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card text-muted-foreground border-border hover:border-primary/40 hover:text-foreground"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Grid */}
          <div className="max-w-6xl mx-auto px-6 pb-20">
            {filtered.length === 0 ? (
              <div className="text-center py-24 text-muted-foreground">
                <p className="font-[Playfair_Display,serif] text-2xl mb-2">No results found</p>
                <p className="text-sm">Try adjusting your filters or search.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map((opp) => (
                  <article
                    key={opp.id}
                    className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col group hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                  >
                    <div className="relative h-44 overflow-hidden bg-muted">
                      <img
                        src={opp.image}
                        alt={opp.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                      <span
                        className={`absolute top-3 left-3 inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium backdrop-blur-sm ${CATEGORY_COLORS[opp.category]}`}
                      >
                        {CATEGORY_ICONS[opp.category]}
                        {opp.category}
                      </span>
                    </div>
                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-9 h-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-xs font-[DM_Mono,monospace] font-semibold shrink-0">
                          {opp.company.logo}
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">{opp.company.name}</p>
                          <h2 className="font-[Playfair_Display,serif] font-semibold text-foreground leading-tight">
                            {opp.title}
                          </h2>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 mb-4 flex-1">
                        {opp.description}
                      </p>
                      <div className="flex flex-col gap-1.5 mb-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1.5">
                          <MapPin size={12} className="text-accent" />
                          {opp.location}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Clock size={12} className="text-accent" />
                          {opp.commitment}
                        </span>
                        <span className="flex items-center gap-1.5">
                          <Users size={12} className="text-accent" />
                          {opp.spots} spots open
                        </span>
                      </div>
                      <div className="flex flex-col gap-2 pt-4 border-t border-border">
                        <button
                          onClick={() => { setApplyModal(opp); setApplySuccess(false); }}
                          className="w-full py-2.5 text-sm font-semibold rounded-full bg-primary text-primary-foreground hover:opacity-90 transition-all flex items-center justify-center gap-1.5"
                        >
                          <Send size={13} />
                          Apply now
                        </button>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setDetailModal(opp)}
                            className="flex-1 py-2 text-sm font-medium rounded-full bg-secondary text-foreground hover:bg-muted transition-all"
                          >
                            View details
                          </button>
                          <button
                            onClick={() => setContactModal(opp)}
                            className="flex-1 py-2 text-sm font-medium rounded-full bg-accent text-accent-foreground hover:opacity-90 transition-all"
                          >
                            Contact
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Post View */}
      {view === "post" && (
        <div className="max-w-2xl mx-auto px-6 py-16">
          {postSuccess ? (
            <div className="text-center py-24">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Heart size={28} className="text-primary" fill="currentColor" />
              </div>
              <h2 className="font-[Playfair_Display,serif] text-3xl font-bold text-foreground mb-3">
                Opportunity posted!
              </h2>
              <p className="text-muted-foreground">
                Your listing is now live and visible to volunteers. Redirecting you to browse…
              </p>
            </div>
          ) : (
            <>
              <div className="mb-10">
                <p className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-accent mb-3">
                  For organizations
                </p>
                <h1 className="font-[Playfair_Display,serif] text-4xl font-bold text-foreground mb-3">
                  Post a volunteer opportunity
                </h1>
                <p className="text-muted-foreground">
                  Share your need with volunteers ready to contribute. All contact information you provide will be shown to users who express interest.
                </p>
              </div>
              <form onSubmit={handlePost} className="space-y-6">
                {/* Company Section */}
                <fieldset className="bg-card border border-border rounded-2xl p-6 space-y-4">
                  <legend className="font-[Playfair_Display,serif] font-semibold text-foreground px-1 -mt-3 bg-card">
                    Organization info
                  </legend>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Organization name *</label>
                    <input
                      required
                      value={postForm.companyName}
                      onChange={(e) => setPostForm({ ...postForm, companyName: e.target.value })}
                      placeholder="e.g. GreenCity Alliance"
                      className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Contact email *</label>
                      <input
                        required
                        type="email"
                        value={postForm.email}
                        onChange={(e) => setPostForm({ ...postForm, email: e.target.value })}
                        placeholder="volunteers@org.org"
                        className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Phone number</label>
                      <input
                        value={postForm.phone}
                        onChange={(e) => setPostForm({ ...postForm, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Website</label>
                    <input
                      value={postForm.website}
                      onChange={(e) => setPostForm({ ...postForm, website: e.target.value })}
                      placeholder="yourorg.org"
                      className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                    />
                  </div>
                </fieldset>

                {/* Opportunity Section */}
                <fieldset className="bg-card border border-border rounded-2xl p-6 space-y-4">
                  <legend className="font-[Playfair_Display,serif] font-semibold text-foreground px-1 -mt-3 bg-card">
                    Opportunity details
                  </legend>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Title *</label>
                    <input
                      required
                      value={postForm.title}
                      onChange={(e) => setPostForm({ ...postForm, title: e.target.value })}
                      placeholder="e.g. Weekend Tree Planting Crew"
                      className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Category *</label>
                      <div className="relative">
                        <select
                          required
                          value={postForm.category}
                          onChange={(e) => setPostForm({ ...postForm, category: e.target.value as Exclude<Category, "All"> })}
                          className="w-full appearance-none px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition pr-9"
                        >
                          {(["Environment", "Education", "Health", "Arts", "Community"] as const).map((c) => (
                            <option key={c}>{c}</option>
                          ))}
                        </select>
                        <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Location *</label>
                      <input
                        required
                        value={postForm.location}
                        onChange={(e) => setPostForm({ ...postForm, location: e.target.value })}
                        placeholder="City, ST"
                        className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Time commitment *</label>
                      <input
                        required
                        value={postForm.commitment}
                        onChange={(e) => setPostForm({ ...postForm, commitment: e.target.value })}
                        placeholder="e.g. Saturdays, 9am–1pm"
                        className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Spots available *</label>
                      <input
                        required
                        type="number"
                        min="1"
                        value={postForm.spots}
                        onChange={(e) => setPostForm({ ...postForm, spots: e.target.value })}
                        placeholder="10"
                        className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Description *</label>
                    <textarea
                      required
                      rows={4}
                      value={postForm.description}
                      onChange={(e) => setPostForm({ ...postForm, description: e.target.value })}
                      placeholder="Describe the role, what volunteers will do, and any requirements…"
                      className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Skills / tags</label>
                    <input
                      value={postForm.skills}
                      onChange={(e) => setPostForm({ ...postForm, skills: e.target.value })}
                      placeholder="e.g. Teamwork, Outdoors, Bilingual"
                      className="w-full px-4 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                    />
                  </div>
                </fieldset>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-full bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
                >
                  Publish listing
                  <ArrowRight size={16} />
                </button>
              </form>
            </>
          )}
        </div>
      )}

      {/* Detail Modal */}
      {detailModal && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6"
          onClick={() => setDetailModal(null)}
        >
          <div
            className="bg-card w-full sm:max-w-2xl rounded-t-3xl sm:rounded-2xl overflow-hidden max-h-[90vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-56 bg-muted">
              <img
                src={detailModal.image}
                alt={detailModal.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <button
                onClick={() => setDetailModal(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-black/40 text-white flex items-center justify-center hover:bg-black/60 transition"
              >
                <X size={16} />
              </button>
              <span
                className={`absolute bottom-4 left-5 inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${CATEGORY_COLORS[detailModal.category]}`}
              >
                {CATEGORY_ICONS[detailModal.category]}
                {detailModal.category}
              </span>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-xs font-[DM_Mono,monospace] font-semibold">
                  {detailModal.company.logo}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{detailModal.company.name}</p>
                  <h2 className="font-[Playfair_Display,serif] font-bold text-xl text-foreground">
                    {detailModal.title}
                  </h2>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3 mb-5">
                <div className="bg-secondary rounded-xl p-3">
                  <MapPin size={14} className="text-accent mb-1" />
                  <p className="text-xs text-muted-foreground">Location</p>
                  <p className="text-sm font-medium text-foreground">{detailModal.location}</p>
                </div>
                <div className="bg-secondary rounded-xl p-3">
                  <Clock size={14} className="text-accent mb-1" />
                  <p className="text-xs text-muted-foreground">Commitment</p>
                  <p className="text-sm font-medium text-foreground">{detailModal.commitment}</p>
                </div>
                <div className="bg-secondary rounded-xl p-3">
                  <Users size={14} className="text-accent mb-1" />
                  <p className="text-xs text-muted-foreground">Spots open</p>
                  <p className="text-sm font-medium text-foreground">{detailModal.spots}</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-5">{detailModal.description}</p>
              <div className="mb-6">
                <p className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-muted-foreground mb-2">
                  Skills helpful
                </p>
                <div className="flex flex-wrap gap-2">
                  {detailModal.skills.map((s) => (
                    <span key={s} className="px-3 py-1 bg-secondary rounded-full text-xs text-foreground">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => { setDetailModal(null); setApplyModal(detailModal); setApplySuccess(false); }}
                  className="w-full py-3 rounded-full bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition flex items-center justify-center gap-2"
                >
                  <Send size={15} />
                  Apply to this opportunity
                </button>
                <button
                  onClick={() => { setDetailModal(null); setContactModal(detailModal); }}
                  className="w-full py-3 rounded-full bg-secondary text-foreground font-semibold text-sm hover:bg-muted transition flex items-center justify-center gap-2"
                >
                  <Mail size={15} />
                  Contact {detailModal.company.name}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Apply Modal */}
      {applyModal && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6"
          onClick={() => { if (!applySuccess) setApplyModal(null); }}
        >
          <div
            className="bg-card w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl overflow-hidden max-h-[92vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {applySuccess ? (
              <div className="p-10 text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-5">
                  <CheckCircle size={32} className="text-primary" />
                </div>
                <h2 className="font-[Playfair_Display,serif] text-2xl font-bold text-foreground mb-2">
                  Application sent!
                </h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Your application has been submitted to{" "}
                  <span className="font-medium text-foreground">{applyModal.company.name}</span>. They will
                  reach out to you at <span className="font-medium text-foreground">{applyForm.email}</span>.
                </p>
              </div>
            ) : (
              <>
                {/* Header */}
                <div className="sticky top-0 bg-card border-b border-border px-6 py-4 flex items-start justify-between z-10">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-xs font-[DM_Mono,monospace] font-semibold shrink-0">
                      {applyModal.company.logo}
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{applyModal.company.name}</p>
                      <h2 className="font-[Playfair_Display,serif] font-bold text-base text-foreground leading-tight">
                        {applyModal.title}
                      </h2>
                    </div>
                  </div>
                  <button
                    onClick={() => setApplyModal(null)}
                    className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition shrink-0"
                  >
                    <X size={15} />
                  </button>
                </div>

                <form onSubmit={handleApply} className="p-6 space-y-5">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Your application will be sent directly to{" "}
                    <span className="font-medium text-foreground">{applyModal.company.name}</span> at{" "}
                    <span className="font-medium text-foreground">{applyModal.company.email}</span>.
                  </p>

                  {/* Personal info */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-3">
                      <User size={13} className="text-accent" />
                      <span className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-muted-foreground">
                        Personal info
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mb-3">
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">First name *</label>
                        <input
                          required
                          value={applyForm.firstName}
                          onChange={(e) => setApplyForm({ ...applyForm, firstName: e.target.value })}
                          placeholder="Ada"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">Last name *</label>
                        <input
                          required
                          value={applyForm.lastName}
                          onChange={(e) => setApplyForm({ ...applyForm, lastName: e.target.value })}
                          placeholder="Lovelace"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">Email *</label>
                        <input
                          required
                          type="email"
                          value={applyForm.email}
                          onChange={(e) => setApplyForm({ ...applyForm, email: e.target.value })}
                          placeholder="ada@example.com"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">Phone</label>
                        <input
                          type="tel"
                          value={applyForm.phone}
                          onChange={(e) => setApplyForm({ ...applyForm, phone: e.target.value })}
                          placeholder="+1 (555) 000-0000"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Availability */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-3">
                      <Calendar size={13} className="text-accent" />
                      <span className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-muted-foreground">
                        Availability
                      </span>
                    </div>
                    <label className="block text-xs font-medium text-foreground mb-1.5">
                      When are you available? *
                    </label>
                    <input
                      required
                      value={applyForm.availability}
                      onChange={(e) => setApplyForm({ ...applyForm, availability: e.target.value })}
                      placeholder={`e.g. ${applyModal.commitment}`}
                      className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition"
                    />
                  </div>

                  {/* Background */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-3">
                      <FileText size={13} className="text-accent" />
                      <span className="text-xs font-[DM_Mono,monospace] uppercase tracking-widest text-muted-foreground">
                        Background
                      </span>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">
                          Relevant experience or skills
                        </label>
                        <textarea
                          rows={3}
                          value={applyForm.experience}
                          onChange={(e) => setApplyForm({ ...applyForm, experience: e.target.value })}
                          placeholder="Briefly describe any relevant background, skills, or past volunteer work…"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition resize-none"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-foreground mb-1.5">
                          Why do you want to volunteer here? *
                        </label>
                        <textarea
                          required
                          rows={3}
                          value={applyForm.motivation}
                          onChange={(e) => setApplyForm({ ...applyForm, motivation: e.target.value })}
                          placeholder="Tell the organization why you're interested in this opportunity…"
                          className="w-full px-3.5 py-2.5 bg-input-background border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-ring/40 transition resize-none"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-full bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
                    >
                      <Send size={15} />
                      Submit application to {applyModal.company.name}
                    </button>
                    <p className="text-center text-xs text-muted-foreground mt-3">
                      Your details will be sent to {applyModal.company.email}
                    </p>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      {view === "browse" && (
        <footer className="border-t border-border bg-card">
          <div className="max-w-6xl mx-auto px-6 py-6 text-center">
            <p className="text-xs text-muted-foreground">
              This app was created by{" "}
              <span className="font-medium text-foreground">Juan Ortiz</span>,{" "}
              <span className="font-medium text-foreground">Muhssina Traore</span> and{" "}
              <span className="font-medium text-foreground">Sincere Shakur</span>{" "}
              during <span className="font-medium text-foreground">TTL Summer Camp</span> · 2026.
            </p>
          </div>
        </footer>
      )}

      {/* Contact Modal */}
      {contactModal && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6"
          onClick={() => setContactModal(null)}
        >
          <div
            className="bg-card w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 text-primary flex items-center justify-center text-sm font-[DM_Mono,monospace] font-semibold">
                    {contactModal.company.logo}
                  </div>
                  <div>
                    <h2 className="font-[Playfair_Display,serif] font-bold text-lg text-foreground">
                      {contactModal.company.name}
                    </h2>
                    <p className="text-xs text-muted-foreground">Contact information</p>
                  </div>
                </div>
                <button
                  onClick={() => setContactModal(null)}
                  className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground transition"
                >
                  <X size={15} />
                </button>
              </div>
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                {contactModal.company.description}
              </p>
              <div className="space-y-3 mb-6">
                <a
                  href={`mailto:${contactModal.company.email}`}
                  className="flex items-center gap-4 p-4 rounded-xl bg-secondary hover:bg-primary/10 transition group"
                >
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition">
                    <Mail size={16} />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Email</p>
                    <p className="text-sm font-medium text-foreground">{contactModal.company.email}</p>
                  </div>
                </a>
                {contactModal.company.phone && (
                  <a
                    href={`tel:${contactModal.company.phone}`}
                    className="flex items-center gap-4 p-4 rounded-xl bg-secondary hover:bg-primary/10 transition group"
                  >
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition">
                      <Phone size={16} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Phone</p>
                      <p className="text-sm font-medium text-foreground">{contactModal.company.phone}</p>
                    </div>
                  </a>
                )}
                {contactModal.company.website && (
                  <a
                    href={`https://${contactModal.company.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-4 p-4 rounded-xl bg-secondary hover:bg-primary/10 transition group"
                  >
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition">
                      <Globe size={16} />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Website</p>
                      <p className="text-sm font-medium text-foreground">{contactModal.company.website}</p>
                    </div>
                  </a>
                )}
              </div>
              <button
                onClick={() => { setContactModal(null); setApplyModal(contactModal); setApplySuccess(false); }}
                className="w-full py-3 rounded-full bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 transition flex items-center justify-center gap-2 mb-3"
              >
                <Send size={15} />
                Apply to this opportunity
              </button>
              <div className="pt-3 border-t border-border">
                <p className="text-xs text-muted-foreground text-center">
                  Listing for: <span className="font-medium text-foreground">{contactModal.title}</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
